kill $(ps aux|grep com.github.gurpreetsachdeva.creditcardsaggregatorservice.CreditCardsAggregatorServiceApplication|awk '{print $2}')
